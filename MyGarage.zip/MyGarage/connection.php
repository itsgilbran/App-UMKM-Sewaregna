<?php
$dbname = "webgis";
$dbuser = "root";
$dbpass = "";
$dbhost = "localhost";
$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
